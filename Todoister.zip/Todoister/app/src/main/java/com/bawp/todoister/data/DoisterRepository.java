package com.bawp.todoister.data;

import android.app.Application;
import android.media.Ringtone;

import androidx.lifecycle.LiveData;

import com.bawp.todoister.model.Task;
import com.bawp.todoister.util.TaskRoomDatabase;

import java.util.List;

public class DoisterRepository  {

    private final TaskDao taskDao;

    private final LiveData<List<Task>> allTask;

    public DoisterRepository(Application application){
        TaskRoomDatabase database = TaskRoomDatabase.getDatabase(application.getApplicationContext());
        this.taskDao = database.taskDao();

        allTask = taskDao.getTAsk();
    }

    public LiveData<List<Task>> getAllTask(){
        return allTask;
    }

    public LiveData<Task> getParticularTask(long id){
        return taskDao.getParticularTask(id);
    }

    public void deleteAll(){
        taskDao.deleteAll();
    }

    public void deleteParticularTask(Task task){

        TaskRoomDatabase.databaseWriterExecutor.execute(new Runnable() {
            @Override
            public void run() {
                taskDao.deleteParticularTask(task);
            }
        });
    }

    public void insert(Task task){

        TaskRoomDatabase.databaseWriterExecutor.execute(new Runnable() {
            @Override
            public void run() {
                taskDao.insertTask(task);
            }
        });
    }

    public void update(Task task){

        TaskRoomDatabase.databaseWriterExecutor.execute(new Runnable() {
            @Override
            public void run() {
                taskDao.updateTask(task);
            }
        });
    }
}
