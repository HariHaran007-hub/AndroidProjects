package com.bawp.todoister.model;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.bawp.todoister.data.DoisterRepository;

import java.util.List;

public class TaskViewModel extends AndroidViewModel {

    private static DoisterRepository repository;

    private final LiveData<List<Task>> allTask;

    public TaskViewModel(@NonNull Application application) {
        super(application);

        repository = new DoisterRepository(application);

        allTask = repository.getAllTask();
    }

    public LiveData<List<Task>> getAllTask(){
        return allTask;
    }

    public static void insert(Task task){
        repository.insert(task);
    }

    public static void deleteParticularTask(Task task){
        repository.deleteParticularTask(task);
    }

    public LiveData<Task> getParticularTask(long id){
        return repository.getParticularTask(id);
    }

    public static void update(Task task){
        repository.update(task);
    }

}
