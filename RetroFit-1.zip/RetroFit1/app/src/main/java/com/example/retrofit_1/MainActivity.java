package com.example.retrofit_1;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private TextView textViewResult;

    private JsonPlaceHolderApi jsonPlaceHolderApi;

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textViewResult = findViewById(R.id.text_view_result);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://jsonplaceholder.typicode.com/")
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                ;

         jsonPlaceHolderApi = retrofit.create(JsonPlaceHolderApi.class);

         //getPosts();

        //getComments();
        createPosts();

    }

    private void getComments() {

        Call<List<Comment>> call = jsonPlaceHolderApi.getComments("posts/3/comments");
        call.enqueue(new Callback<List<Comment>>() {
            @Override
            public void onResponse(Call<List<Comment>> call, Response<List<Comment>> response) {
                if(!response.isSuccessful()){
                    textViewResult.setText("code "+response.code());
                    return;
                }

                List<Comment> comments = response.body();

                for (Comment comment : comments){
                    String content = "";
                    content += "Id: "+comment.getId()+"\n";
                    content += "Name: "+comment.getName()+"\n";
                    content += "Email: "+comment.getEmail()+"\n";
                    content += "Text: "+comment.getText()+"\n\n";
                    textViewResult.append(content);
                }

            }

            @Override
            public void onFailure(Call<List<Comment>> call, Throwable t) {
                textViewResult.setText(t.getMessage());
            }
        });

    }


    public void getPosts(){

//        Call<List<Post>> call = jsonPlaceHolderApi.getPosts(1,4,"id","desc");
//        Call<List<Post>> call = jsonPlaceHolderApi.getPosts(new Integer[]{1,2,3},"id","desc");


        //For query map
        Map<String,String> parameters = new HashMap<>();
        parameters.put("userId","1");
        parameters.put("_sort","id");
        parameters.getOrDefault("_order","desc");

        Call<List<Post>> call = jsonPlaceHolderApi.getPosts(parameters);



        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(Call<List<Post>> call, Response<List<Post>> response) {

                if(!response.isSuccessful()){
                    textViewResult.setText("code "+response.code());
                    return;
                }

                List<Post> posts = response.body();
                for(Post post : posts){
                    String content = "";
                    content += "ID: "+post.getId()+"\n";
                    content += "User Id: "+post.getUserId()+"\n";
                    content += "Title: "+post.getTitle()+"\n";
                    content += "Text: "+post.getText() +"\n\n";
                    textViewResult.append(content);
                }
            }

            @Override
            public void onFailure(Call<List<Post>> call, Throwable t) {
                textViewResult.setText(t.getMessage());
            }
        });
    }


    private void createPosts(){


//        Post post = new Post(23,"New Title","New Text");
//        Call<Post> call = jsonPlaceHolderApi.createPost(post);

//        Call<Post> call = jsonPlaceHolderApi.createPost(23,"New Title","New Text");

        Map<String , String> fields = new HashMap<>();
        fields.put("userId","25");
        fields.put("tittle","New Title");
        Call<Post> call = jsonPlaceHolderApi.createPost(fields);




        call.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                if(!response.isSuccessful()){
                    textViewResult.setText(response.code());
                    return;
                }
                Post postResponse = response.body();
                String content = "";

                content += "Code "+response.code()+"\n";
                content += "ID: "+postResponse.getId()+"\n";
                content += "User Id: "+postResponse.getUserId()+"\n";
                content += "Title: "+postResponse.getTitle()+"\n";
                content += "Text: "+postResponse.getText() +"\n\n";
                textViewResult.setText(content);
            }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {
                textViewResult.setText(t.getMessage());
            }
        });
    }

}
