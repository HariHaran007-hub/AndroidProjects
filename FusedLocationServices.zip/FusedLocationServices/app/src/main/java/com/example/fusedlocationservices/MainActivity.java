package com.example.fusedlocationservices;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.location.Location;

import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import org.w3c.dom.Text;

import java.net.PasswordAuthentication;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener, LocationListener {

    private static final int ALL_PERMISSIONS_RESULT = 1111;
    private static final int UPDATE_INTERVAL = 5000;
    private static final int FASTEST_INTERVAL = 5000;
    private GoogleApiClient client;
    private ArrayList<String> permissionsToRequest;
    private ArrayList<String> permissions = new ArrayList<>();
    private ArrayList<String> permissionRejected = new ArrayList<>();
    private TextView textView;

    private FusedLocationProviderClient fusedLocationProviderClient;

    //gms location request
    private LocationRequest locationRequest;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.location_text_view);

        //Set upping the client
        client = new GoogleApiClient.Builder(this.getApplicationContext())
                .addApi(LocationServices.API)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .build();


        //necessary permissions are added in permissions array list
        //This can be cross checked with with all accepted or not
        //In case permission which was yet to be accepted are added in permissionToRequest array list
        //In case permissions which was rejected are added in permissionRejected array list
        permissions.add(Manifest.permission.ACCESS_FINE_LOCATION);
        permissions.add(Manifest.permission.ACCESS_COARSE_LOCATION);

        //Not accepted permissions are stored here(Note it is not rejected)
        permissionsToRequest = permissionsToRequest(permissions);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (permissionsToRequest.size() > 0) {
                //this is the method to request permissions
                requestPermissions(permissionsToRequest.toArray(
                        new String[permissionsToRequest.size()]), ALL_PERMISSIONS_RESULT);
            }
        }


    }

    private ArrayList<String> permissionsToRequest(ArrayList<String> permissions) {

        ArrayList<String> result = new ArrayList<>();
        for (String perm : permissions) {
            if (!hasPermissions(perm)) {
                result.add(perm);
            }
        }
        return result;

    }

    private boolean hasPermissions(String perm) {
        //if our android version are greater we need to check this
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
        }
        //for api less than 24
        return true;
    }

    //Checking weather play services is working or not
    private void checkPlayServices() {
        int errorCode = GoogleApiAvailability.getInstance()
                .isGooglePlayServicesAvailable(MainActivity.this);

        if (errorCode != ConnectionResult.SUCCESS) {
            Dialog dialog = GoogleApiAvailability.getInstance()
                    .getErrorDialog(MainActivity.this, errorCode, errorCode,
                            new DialogInterface.OnCancelListener() {
                                @Override
                                public void onCancel(DialogInterface dialog) {
                                    Toast.makeText(MainActivity.this.getApplicationContext(),
                                            "Connections Error", Toast.LENGTH_SHORT).show();
                                    finish();
                                }
                            });
            dialog.show();
        } else {
            Toast.makeText(MainActivity.this.getApplicationContext(),
                    "Connected successfully", Toast.LENGTH_SHORT).show();
        }

    }

    //If user come out of the activity but not exited the application means this will work to disconnect
    //Location services
    @Override
    protected void onPause() {
        super.onPause();

        if (client != null && client.isConnected()) {
            LocationServices.getFusedLocationProviderClient(MainActivity.this.getApplicationContext())
                    .removeLocationUpdates(new LocationCallback() {
                        //not necessary for now
                    });
            client.disconnect();
        }
    }

    //To check wether all permissions are granted or not
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode){
            case ALL_PERMISSIONS_RESULT:
                for(String perm : permissionsToRequest){
                    if(!hasPermissions(perm)){
                        permissionRejected.add(perm);
                    }
                }

                if(permissionRejected.size() > 0){
                    if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                        if(shouldShowRequestPermissionRationale(permissionRejected.get(0))){
                            new AlertDialog.Builder(MainActivity.this.getApplicationContext())
                                    .setMessage("These permissions are mandatory")
                                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            requestPermissions(permissionRejected.toArray(new String[permissionRejected.size()]),
                                                    ALL_PERMISSIONS_RESULT);
                                        }
                                    })
                                    .setNegativeButton("Cancel",null)
                                .create()
                                .show();
                        }
                    }
                }else{
                    if(client != null){
                        client.connect();
                    }
                }
        }


    }

    @Override
    protected void onPostResume() {
        super.onPostResume();
        checkPlayServices();
        startLocationUpdate();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        //Checking again for the permissions accepted r not
        if (ActivityCompat.checkSelfPermission(MainActivity.this.getApplicationContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(MainActivity.this.getApplicationContext(),
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            return;
        }

        fusedLocationProviderClient.getLastLocation()
                .addOnSuccessListener(MainActivity.this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        textView.setText(String.format("Lat: %s Long: %s", location.getLatitude(), location.getLongitude()));
                    }
                });
    }

    //Requesting api to get frequent updates
    private void startLocationUpdate(){
        locationRequest = new LocationRequest();
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY)
                .setInterval(UPDATE_INTERVAL)
                .setFastestInterval(FASTEST_INTERVAL);

        //checking again for the permission granted or not

        if(ActivityCompat.checkSelfPermission(MainActivity.this.getApplicationContext(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED&&
        ActivityCompat.checkSelfPermission(MainActivity.this.getApplicationContext()
                ,Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            Toast.makeText(MainActivity.this.getApplicationContext(),"Enable locations",Toast.LENGTH_SHORT)
                    .show();
        }else{
            LocationServices.getFusedLocationProviderClient(MainActivity.this)
                    .requestLocationUpdates(locationRequest, new LocationCallback() {
                        @Override
                        public void onLocationResult(@NonNull LocationResult locationResult) {
                            super.onLocationResult(locationResult);
                            if(locationResult != null){
                                Location location = locationResult.getLastLocation();
                                textView.setText(String.format("Lat: %s Long: %s", location.getLatitude(), location.getLongitude()));
                            }
                        }

                        @Override
                        public void onLocationAvailability(@NonNull LocationAvailability locationAvailability) {
                            super.onLocationAvailability(locationAvailability);
                        }
                    },null);
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(@NonNull Location location) {

    }
}