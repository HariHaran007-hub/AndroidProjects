package com.example.hariscollections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.hariscollections.model.Customer;
import com.example.hariscollections.model.CustomerViewModel;

public class AddCustomersActivity extends AppCompatActivity {

    public  static EditText customerName;
    private static EditText customerNumber;
    private static EditText noOfSarees;
    private static EditText totalCost;
    private static EditText dateOfPurchase;
    private static EditText amountPaid;

    private static Button addButton;

    private  static CustomerViewModel customerViewModel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_customers);


        //Geting database using view model

        customerViewModel = new ViewModelProvider.AndroidViewModelFactory(AddCustomersActivity.this
                .getApplication()).create(CustomerViewModel.class);

        customerName = findViewById(R.id.customer_name);
        customerNumber = findViewById(R.id.customer_number);
        noOfSarees = findViewById(R.id.customer_sareepurchase);
        totalCost = findViewById(R.id.customer_totalcost);
        dateOfPurchase = findViewById(R.id.customer_dateofpurchase);
        amountPaid = findViewById(R.id.customer_amountpaid);
        addButton = findViewById(R.id.customer_add);

        addButton(this.getApplicationContext());
    }


    private  void addButton(Context context){
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Intent replyIntent = new Intent();
                if(customerName.getText().toString().isEmpty() &&
                    customerNumber.getText().toString().isEmpty() &&
                        noOfSarees.getText().toString().isEmpty() &&
                        totalCost.getText().toString().isEmpty()&&
                        dateOfPurchase.getText().toString().isEmpty()&&
                        amountPaid.getText().toString().isEmpty()){
                    Toast.makeText(context,"Invalid Details",Toast.LENGTH_SHORT).show();
                    setResult(RESULT_CANCELED);
                }else{
                    Customer customer = new Customer(customerName.getText().toString(),
                            customerNumber.getText().toString(),noOfSarees.getText().toString(),
                            Double.parseDouble(totalCost.getText().toString()),dateOfPurchase.getText().toString(),
                            Double.parseDouble( amountPaid.getText().toString()));

                    customerViewModel.addCustomer(customer);
                    setResult(RESULT_OK);
                    finish();
                }
            }
        });
    }
}