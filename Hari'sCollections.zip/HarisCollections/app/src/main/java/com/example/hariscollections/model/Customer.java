package com.example.hariscollections.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Customer_Table")
public class Customer {

    @PrimaryKey(autoGenerate = true)
    private int id;

    @ColumnInfo(name = "Customer Name")
    private String customerName;

    @ColumnInfo(name = "Phone Number")
    private String phoneNumber;

    @ColumnInfo(name  = "Sarees Purchased")
    private String noOfSareesPurchased;

    @ColumnInfo(name = "Total Cost")
    private double totalCost;

    @ColumnInfo(name  = "Purchase Data")
    private String dateOfPurchase;

    @ColumnInfo(name = "Amount Paid")
    private double amountPaid;

    @ColumnInfo(name = "Balance Amount")
    private double balanceAmount;

    @ColumnInfo(name = "Last Payed")
    private String lastPayedDate;


    public Customer(String customerName, String phoneNumber, String noOfSareesPurchased, double totalCost, String dateOfPurchase,double amountPaid) {
        this.customerName = customerName;
        this.phoneNumber = phoneNumber;
        this.noOfSareesPurchased = noOfSareesPurchased;
        this.totalCost = totalCost;
        this.dateOfPurchase = dateOfPurchase;
        this.amountPaid = amountPaid;

        if(this.totalCost > this.amountPaid )
            this.balanceAmount = this.totalCost - this.amountPaid;
    }

    public int getId() {
        return id;
    }


    public void setId(int id) {
        this.id = id;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getNoOfSareesPurchased() {
        return noOfSareesPurchased;
    }

    public void setNoOfSareesPurchased(String noOfSareesPurchased) {
        this.noOfSareesPurchased = noOfSareesPurchased;
    }

    public double getTotalCost() {
        return totalCost;
    }

    public void setTotalCost(double totalCost) {
        this.totalCost = totalCost;
    }

    public String getDateOfPurchase() {
        return dateOfPurchase;
    }

    public void setDateOfPurchase(String dateOfPurchase) {
        this.dateOfPurchase = dateOfPurchase;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public double getBalanceAmount() {
        return balanceAmount;
    }

    public void setBalanceAmount(double balanceAmount) {
        this.balanceAmount = balanceAmount;
    }

    public String getLastPayedDate() {
        return lastPayedDate;
    }

    public void setLastPayedDate(String lastPayedDate) {
        this.lastPayedDate = lastPayedDate;
    }
}
