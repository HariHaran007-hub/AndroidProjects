package com.example.hariscollections;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.hariscollections.adapter.RecyclerViewAdapter;
import com.example.hariscollections.model.Customer;
import com.example.hariscollections.model.CustomerViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements RecyclerViewAdapter.OnCustomerClickListener {

    public static final String CUSTOMER_ID = "customer_id";
    public static RecyclerView recyclerView;

    public Customer customer;

    public FloatingActionButton floatingActionButton;

    public  RecyclerViewAdapter recyclerViewAdapter;

    public CustomerViewModel customerViewModel;

    public static int ADDING_REQUESTCODE = 1;

    //The below five fields for passing the intent data (function and keys)
    public static final String CUSTOMER_NAME = "customer_name";

    public static final String CUSTOMER_NUMBER = "customer_number";

    public static final String CUSTOMER_LASTPAYED = "customer_lastpayed";

    public static final String TOTAL_COST = "total_cost";

    public static final String AMOUNT_PAID = "amount_paid";

    public static final String BALANCE_AMOUNT = "balance_amount";

    public static final String CUSTOMER_SAREE = "customer_saree";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Objects.requireNonNull(getSupportActionBar()).hide();

        recyclerView = findViewById(R.id.recycle_view);
        recyclerView.setLayoutManager(new LinearLayoutManager(this.getApplicationContext()));
        recyclerView.setHasFixedSize(true);

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();



        customerViewModel = new ViewModelProvider.AndroidViewModelFactory(MainActivity.this
                .getApplication()).create(CustomerViewModel.class);

//        customerViewModel.addCustomer(new Customer("Guna Sundari R"
//                ,"8168213517","6",5000, dtf.format(now),1450));
//
//        customerViewModel.addCustomer(new Customer("Ravi Chandran"
//                ,"9150622176","6",5000, dtf.format(now),1450));
//
//        customerViewModel.addCustomer(new Customer("Siva Kumar"
//                ,"91506758301","6",5000, dtf.format(now),1450));
//
//        customerViewModel.addCustomer(new Customer("Jones"
//                ,"91501827342w","6",5000, dtf.format(now),1450));




        customerViewModel.getCustomerList().observe(this, new Observer<List<Customer>>() {
            @SuppressLint("NotifyDataSetChanged")
            @Override
            public void onChanged(List<Customer> customers) {
                recyclerViewAdapter = new RecyclerViewAdapter(customers,MainActivity.this.getApplicationContext()
                ,MainActivity.this);

                recyclerViewAdapter.notifyDataSetChanged();


                recyclerView.setAdapter(recyclerViewAdapter);



            }
        });

        floatingActionButton = findViewById(R.id.add_customer);

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,AddCustomersActivity.class);
                startActivityForResult(intent,ADDING_REQUESTCODE);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == ADDING_REQUESTCODE && resultCode == RESULT_OK){
           // Toast.makeText( MainActivity.this,"Customer account added successfully", Toast.LENGTH_SHORT).show();
            Snackbar.make(recyclerView,"Customer Account added successfully!!",Snackbar.LENGTH_LONG).show();
        }
    }


// @SuppressLint("NotifyDataSetChanged")
    @Override
    public void onCustomerClick(int position) {






        customer = Objects.requireNonNull(customerViewModel.getCustomerList().getValue()).get(position);

        if(customer == null){
            customer = Objects.requireNonNull(customerViewModel.getCustomerList().getValue()).get(position+1);

        }




      //  Log.d("Main","onCreate: "+customer.getTotalCost());
        Intent intent = new Intent(MainActivity.this,CustomerInfoActivity.class);
        Bundle bundle = new Bundle();

        bundle.putInt(CUSTOMER_ID,customer.getId());
        bundle.putString(CUSTOMER_NAME ,customer.getCustomerName());
        bundle.putString(CUSTOMER_SAREE,customer.getNoOfSareesPurchased());
        bundle.putString(CUSTOMER_NUMBER,customer.getPhoneNumber());
        bundle.putString(CUSTOMER_LASTPAYED,customer.getLastPayedDate());
        bundle.putDouble(TOTAL_COST,customer.getTotalCost());
        bundle.putDouble(AMOUNT_PAID,customer.getAmountPaid());
        bundle.putDouble(BALANCE_AMOUNT,customer.getBalanceAmount());

        intent.putExtras(bundle);

        startActivity(intent);
    }
}