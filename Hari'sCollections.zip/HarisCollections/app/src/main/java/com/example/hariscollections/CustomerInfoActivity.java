package com.example.hariscollections;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Text;

public class CustomerInfoActivity extends AppCompatActivity {

    public static final String CUSTOMER_SAREES = "customer_sarees";
    private TextView nameView;

    private TextView numberView;

    private TextView lastPayView;

    private TextView totalCostView;

    private TextView amountPaidView;

    private TextView balanceAmountView;

    private Button updateCustomer;

    public static final String CUSTOMER_NAME = "customer_name";

    public static final String CUSTOMER_NUMBER = "customer_number";

    public static final String CUSTOMER_LASTPAYED = "customer_lastpayed";

    public static final String TOTAL_COST = "total_cost";

    public static final String AMOUNT_PAID = "amount_paid";

    public static final String BALANCE_AMOUNT = "balance_amount";

    public static final String CUSTOMER_ID = "customer_id";

    public static final String CUSTOMER_SAREE = "customer_saree";

    public static final int CUSTOMER_UPDATE_REQUESTCODE = 1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customer_info);


        nameView = findViewById(R.id.info_name);
        numberView = findViewById(R.id.info_number);
        lastPayView = findViewById(R.id.info_lastpay);
        totalCostView = findViewById(R.id.info_totalcost);
        amountPaidView = findViewById(R.id.info_amountpaid);
        balanceAmountView = findViewById(R.id.info_balanceamount);

       updateCustomer =  findViewById(R.id.update_customer);

        if(getIntent().hasExtra(MainActivity.CUSTOMER_ID)){

            nameView.setText(String.format("Name: %s",getIntent().getStringExtra(MainActivity.CUSTOMER_NAME)));

            numberView.setText(String.format("Mobile Number: %s", getIntent().getStringExtra(MainActivity.CUSTOMER_NUMBER)));

            lastPayView.setText(String.format("Last Pay: %s", getIntent().getStringExtra(MainActivity.CUSTOMER_LASTPAYED)));

            totalCostView.setText(String.format("Total Cost: %s", getIntent().getDoubleExtra(MainActivity.TOTAL_COST, 0.00)));

            amountPaidView.setText(String.format("Amount payed: %s", getIntent().getDoubleExtra(MainActivity.AMOUNT_PAID, 0.00)));

            balanceAmountView.setText(String.format("Balance Amount: %s", getIntent().getDoubleExtra(MainActivity.BALANCE_AMOUNT, 0.00)));
        }

        updateCustomer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Bundle data = getIntent().getExtras();

                if(data != null) {

                    Intent intent =new Intent(CustomerInfoActivity.this,UpdateCustomerActivity.class);

                    Log.d("Customer","onCreate: "+data.getDouble(MainActivity.AMOUNT_PAID)+
                            " "+data.getDouble(MainActivity.BALANCE_AMOUNT)+" "+ data.getDouble(MainActivity.TOTAL_COST));

                    Bundle bundle = new Bundle();
                    bundle.putInt(CUSTOMER_ID,data.getInt(MainActivity.CUSTOMER_ID));
                    bundle.putString(CUSTOMER_NAME ,data.getString(MainActivity.CUSTOMER_NAME));
                    bundle.putString(CUSTOMER_SAREE,data.getString(MainActivity.CUSTOMER_SAREE));
                    bundle.putString(CUSTOMER_NUMBER,data.getString(MainActivity.CUSTOMER_NUMBER));
                    bundle.putString(CUSTOMER_LASTPAYED,data.getString(MainActivity.CUSTOMER_LASTPAYED));
                    bundle.putDouble(TOTAL_COST,data.getDouble(MainActivity.TOTAL_COST));
                    bundle.putDouble(AMOUNT_PAID,data.getDouble(MainActivity.AMOUNT_PAID));
                    bundle.putDouble(BALANCE_AMOUNT,data.getDouble(MainActivity.BALANCE_AMOUNT));

                    intent.putExtras(bundle);
                    startActivity(intent);





                    finish();


                }
            }
        });

    }

   }
