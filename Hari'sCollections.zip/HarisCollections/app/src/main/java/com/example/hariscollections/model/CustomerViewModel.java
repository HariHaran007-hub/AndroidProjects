package com.example.hariscollections.model;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.hariscollections.data.CustomerRepository;

import java.util.List;

public class CustomerViewModel extends AndroidViewModel {

    private static CustomerRepository repository ;

    public static LiveData<List<Customer>> customerList;

    public CustomerViewModel(@NonNull Application application) {
        super(application);

        repository = new CustomerRepository(application.getApplicationContext());

        customerList = repository.getCustomerList();
    }

    public void addCustomer(Customer customer){
        repository.addCustomer(customer);
    }

    public void removeCustomer(Customer customer){
        repository.removeCustomer(customer);
    }

    public void updateCustomer(Customer customer){
        repository.updateCustomer(customer);
    }

    public LiveData<Customer> getParticularCustomer(int id){
        return repository.getParticularCustomer(id);
    }

    public LiveData<List<Customer>> getCustomerList(){
        return customerList;
    }
}
