package com.example.hariscollections.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.hariscollections.R;
import com.example.hariscollections.model.Customer;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {


    public  List<Customer> customerList;

    public Context context;

    public OnCustomerClickListener onCustomerClickListener;


    public RecyclerViewAdapter(List<Customer> customerList, Context context,OnCustomerClickListener onCustomerClickListener) {
        this.customerList = customerList;
        this.context = context;
        this.onCustomerClickListener = onCustomerClickListener ;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_customer_info,parent,false);

        return new ViewHolder(view,onCustomerClickListener);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Customer customer = customerList.get(position);

        holder.nameField.setText("Name: "+customer.getCustomerName());
        holder.phoneNumberField.setText("Phone Number: "+customer.getPhoneNumber());
        holder.balanceAmountField.setText("Balance Amount: "+customer.getBalanceAmount());
        holder.lastPayedDateField.setText("Last Payed: "+customer.getLastPayedDate());
    }

    @Override
    public int getItemCount() {
        return customerList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        private TextView nameField;
        private TextView phoneNumberField;
        private TextView balanceAmountField;
        private TextView lastPayedDateField;

        private final OnCustomerClickListener onCustomerClickListener;

        public ViewHolder(@NonNull View itemView,OnCustomerClickListener onCustomerClickListener) {
            super(itemView);

            nameField = itemView.findViewById(R.id.row_customer_name);
            phoneNumberField = itemView.findViewById(R.id.row_customer_number);
            balanceAmountField= itemView.findViewById(R.id.row_customer_balanceamount);
            lastPayedDateField = itemView.findViewById(R.id.row_customer_lastpayed);

            this.onCustomerClickListener = onCustomerClickListener;



            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onCustomerClickListener.onCustomerClick(getAdapterPosition());
        }
    }

    public interface OnCustomerClickListener{
        void onCustomerClick(int position);
    }

}
