package com.example.hariscollections.data;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.example.hariscollections.model.Customer;

import java.util.List;

@Dao
public interface CustomerDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void addCustomer(Customer customer);

    @Delete
    void removeCustomer(Customer customer);

    @Update
    void updateCustomer(Customer customer);

    @Query("SELECT * FROM Customer_Table WHERE Customer_Table.id = :id")
    LiveData<Customer> getParticularCustomer(int id);

    @Query("SELECT * FROM Customer_Table")
    LiveData<List<Customer>> getAllCustomerList();
}
