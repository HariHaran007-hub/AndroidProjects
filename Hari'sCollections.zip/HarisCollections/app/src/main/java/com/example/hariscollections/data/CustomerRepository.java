package com.example.hariscollections.data;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.example.hariscollections.model.Customer;
import com.example.hariscollections.util.CustomerDatabase;

import java.util.List;

public class CustomerRepository {

    private static CustomerDao dao;

    private static LiveData<List<Customer>> customerList;

    public CustomerRepository(Context context) {
        CustomerDatabase database = CustomerDatabase.getDatabase(context);

        //By using dao we can use this for performing curd operations
        dao = database.getCustomerDao();

    }

    //Setuping all CRUD operations

    public void addCustomer(Customer customer){
        CustomerDatabase.databaseExecutorWriter.execute(new Runnable() {
            @Override
            public void run() {
                dao.addCustomer(customer);
            }
        });
    }

    public void removeCustomer(Customer customer){
        CustomerDatabase.databaseExecutorWriter.execute(new Runnable() {
            @Override
            public void run() {
                dao.removeCustomer(customer);
            }
        });
    }

    public void updateCustomer(Customer customer){
        CustomerDatabase.databaseExecutorWriter.execute(new Runnable() {
            @Override
            public void run() {
                dao.updateCustomer(customer);
            }
        });
    }

    public LiveData<List<Customer>> getCustomerList(){
        return dao.getAllCustomerList();
    }

    public LiveData<Customer> getParticularCustomer(int id){
        return dao.getParticularCustomer(id);
    }
}
