package com.example.hariscollections.util;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.hariscollections.MainActivity;
import com.example.hariscollections.data.CustomerDao;
import com.example.hariscollections.model.Customer;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Customer.class} , version = 1,exportSchema = false)
public abstract class CustomerDatabase  extends RoomDatabase {

    public abstract CustomerDao getCustomerDao();

    //Singleton class pattern

    private static final String DATABASE_NAME = "Hari's Collections";

    private static volatile CustomerDatabase INSTANCE;

    private static final int NUMBER_OF_THREADS = 4;

    public static final ExecutorService databaseExecutorWriter = Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public  static  CustomerDatabase getDatabase(final Context context){
        if(INSTANCE == null){
            synchronized (MainActivity.class){
                if (INSTANCE == null){
                    INSTANCE = Room.databaseBuilder(context,CustomerDatabase.class,DATABASE_NAME)
                            .addCallback(sRoomDataBase)
                            .build();
                }
            }
        }
        return INSTANCE;
    }


    //For intial data_set
    private static final  RoomDatabase.Callback sRoomDataBase = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            CustomerDao dao = INSTANCE.getCustomerDao();

            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();

            databaseExecutorWriter.execute(new Runnable() {
                @Override
                public void run() {
                    dao.addCustomer(new Customer("R.C.HARI HARAN","8838387219"
                            ,"3",1300.00,dtf.format(now),600));

                    dao.addCustomer(new Customer("R.CHITRA","89698551437"
                            ,"4",3000.00,dtf.format(now),400));
                }
            });
        }
    };
}
