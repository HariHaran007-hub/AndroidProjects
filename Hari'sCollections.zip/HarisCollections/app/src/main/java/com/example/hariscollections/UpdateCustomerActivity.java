package com.example.hariscollections;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hariscollections.adapter.RecyclerViewAdapter;
import com.example.hariscollections.model.Customer;
import com.example.hariscollections.model.CustomerViewModel;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UpdateCustomerActivity extends AppCompatActivity {

    private TextView updateName;

    private TextView updateBalance;

    private EditText noOfSarees;

    private EditText amountPaid;

    private EditText totalCost;

    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_customer);

        updateName = findViewById(R.id.update_name);
        updateBalance = findViewById(R.id.update_balance);
        noOfSarees = findViewById(R.id.update_saree);
        amountPaid = findViewById(R.id.update_amount);
        totalCost = findViewById(R.id.update_cost);
        saveButton = findViewById(R.id.update_save);

        CustomerViewModel customerViewModel = new ViewModelProvider.AndroidViewModelFactory(UpdateCustomerActivity.this
                .getApplication()).create(CustomerViewModel.class);

        @SuppressLint("SimpleDateFormat")
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        Date date = new Date();

        Bundle data = getIntent().getExtras();

        if(data != null){
            updateName.setText(String.format("Name: %s", data.getString(CustomerInfoActivity.CUSTOMER_NAME)));
            updateBalance.setText(String.format("Balance: %s", String.valueOf(data.getDouble(CustomerInfoActivity.BALANCE_AMOUNT))));

            saveButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(noOfSarees.getText().toString().isEmpty() && amountPaid.getText().toString().isEmpty() && totalCost.getText().toString().isEmpty()){
                        Toast.makeText(UpdateCustomerActivity.this.getApplicationContext(), "Invalid Details!!", Toast.LENGTH_SHORT).show();
                        //setResult(RESULT_CANCELED);

                    }else{
                        double newTotal = Double.parseDouble(totalCost.getText().toString()) + data.getDouble(CustomerInfoActivity.TOTAL_COST);
                        String totalSarees = String.valueOf(Integer.parseInt(noOfSarees.getText().toString())
                                + Integer.parseInt(data.getString(CustomerInfoActivity.CUSTOMER_SAREE)));
                       double newAmountPaid = Double.parseDouble(amountPaid.getText().toString())+data.getDouble(CustomerInfoActivity.AMOUNT_PAID);

                       double newBalance = newTotal - newAmountPaid;

                      //  Customer customer= customerViewModel.getParticularCustomer(data.getInt(CustomerInfoActivity.CUSTOMER_ID)).getValue();

                       customerViewModel.getParticularCustomer(data.getInt(CustomerInfoActivity.CUSTOMER_ID)).observe(UpdateCustomerActivity.this, new Observer<Customer>() {
                            @Override
                            public void onChanged(Customer customer) {


                                assert customer != null;
                                customer.setNoOfSareesPurchased(totalSarees);
                                customer.setAmountPaid(newAmountPaid);
                                customer.setTotalCost(newTotal);
                                customer.setBalanceAmount(newBalance);
                                customerViewModel.updateCustomer(customer);


                            }
                        });

//                       customer = new Customer(data.getString(CustomerInfoActivity.CUSTOMER_NAME),
//                               CustomerInfoActivity.CUSTOMER_NUMBER,totalSarees,newTotal, dateFormat.format(date),newAmountPaid );
//                       customer.setId(data.getInt(CustomerInfoActivity.CUSTOMER_ID));






                        Toast.makeText(UpdateCustomerActivity.this.getApplicationContext(), "Successfully Updated", Toast.LENGTH_SHORT).show();

                    }
                    finish();
                }

            });

        }

        }
    }
