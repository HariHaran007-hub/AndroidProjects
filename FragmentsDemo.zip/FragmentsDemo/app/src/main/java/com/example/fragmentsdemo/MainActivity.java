package com.example.fragmentsdemo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.add_fragment);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addFragment();
            }
        });
    }

    public void addFragment(){
        Fragment fragment;
        FragmentManager fragmentManager = getSupportFragmentManager();



//        SampleFragment sampleFragment = new SampleFragment();
//        fragmentTransaction.add(R.id.fragmentContainer,sampleFragment);
//        fragmentTransaction.addToBackStack(null);
//        fragmentTransaction.commit();

         fragment= fragmentManager.findFragmentById(R.id.fragmentContainer);

        switch (fragmentManager.getBackStackEntryCount()){
            case 0: fragment = new SampleFragment();

            case 1 :  fragment = new SecondFragment();

            case 3:  fragment = new ThirdFragment();

            default:  fragment  = new SampleFragment();

        }

        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        fragmentTransaction.add(R.id.fragmentContainer,fragment);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();



    }
}