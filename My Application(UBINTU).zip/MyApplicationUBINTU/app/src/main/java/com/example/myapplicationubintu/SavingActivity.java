package com.example.myapplicationubintu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapplicationubintu.model.Contact;
import com.example.myapplicationubintu.model.ContactViewModel;
import com.google.android.material.snackbar.Snackbar;

public class SavingActivity extends AppCompatActivity {

    public Button saveButton;

    public EditText nameField;

    public EditText occupationField;

    public EditText numberField;

    private int contactId = 0;

    private boolean isEdit = false;

    private Button updateButton;

    private Button deleteButton;

    public static final String CONTACT_NAME = "contact_name";

    public static  final String CONTACT_OCCUPATION = "contact_occupation";

    public static final String CONTACT_NUMBER  = "contact_number";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saving);


        saveButton = findViewById(R.id.save_button);
        updateButton = findViewById(R.id.update_button);
        deleteButton = findViewById(R.id.delete_button);
        nameField = findViewById(R.id.get_name);
        occupationField = findViewById(R.id.get_occupation);
        numberField = findViewById(R.id.get_number);

        ContactViewModel contactViewModel = new ViewModelProvider.AndroidViewModelFactory(SavingActivity.this
                .getApplication()).create(ContactViewModel.class);


        //for getting updated
        if(getIntent().hasExtra(MainActivity.CONTACT_ID)){
            contactId = getIntent().getIntExtra(MainActivity.CONTACT_ID,0);
            contactViewModel.get(contactId).observe(this, new Observer<Contact>() {
                @Override
                public void onChanged(Contact contact) {
                    if(contact!= null){
                        nameField.setText(contact.getName());
                        occupationField.setText(contact.getOccupation());
                        numberField.setText(contact.getPhoneNumber());

                    }
                }
            });
            isEdit =true;
        }



        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent replyIntent = new Intent();

                if(!nameField.getText().toString().isEmpty() && !occupationField.getText().toString().isEmpty()
                        && !numberField.getText().toString().isEmpty()){

                    replyIntent.putExtra(CONTACT_NAME,nameField.getText().toString());
                    replyIntent.putExtra(CONTACT_OCCUPATION,occupationField.getText().toString());
                    replyIntent.putExtra(CONTACT_NUMBER,numberField.getText().toString());

                    setResult(RESULT_OK,replyIntent);

                }else{
                    Toast.makeText(SavingActivity.this.getApplicationContext(),"Invalid info",Toast.LENGTH_SHORT).show();
                    setResult(RESULT_CANCELED,replyIntent);
                }
                finish();
            }
        });

        //update button
        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = contactId;
                String name = nameField.getText().toString();
                String occupation = occupationField.getText().toString();
                String phoneNumber = numberField.getText().toString();

                if(name.isEmpty() || occupation.isEmpty() || phoneNumber.isEmpty()){
                    Snackbar.make(nameField,"Empty details not accepted",Snackbar.LENGTH_SHORT).show();
                }else{
                    Contact contact  = new Contact(name,occupation,phoneNumber);
                    contact.setId(id);
                    ContactViewModel.update(contact);
                }
                finish();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int id = contactId;
                String name = nameField.getText().toString();
                String occupation = occupationField.getText().toString();
                String phoneNumber = numberField.getText().toString();

                Contact contact = new Contact(name,occupation,phoneNumber);
                contact.setId(id);

                ContactViewModel.delete(contact);
                finish();
            }
        });

        if(isEdit){
            saveButton.setVisibility(View.GONE);
        }else{
            updateButton.setVisibility(View.GONE);
            deleteButton.setVisibility(View.GONE
            );
        }



    }


}