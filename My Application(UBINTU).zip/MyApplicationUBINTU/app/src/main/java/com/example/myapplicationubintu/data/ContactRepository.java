package com.example.myapplicationubintu.data;

import android.app.Application;
import android.media.ApplicationMediaCapabilities;

import androidx.lifecycle.LiveData;

import com.example.myapplicationubintu.model.Contact;
import com.example.myapplicationubintu.util.ContactDatabase;

import java.util.List;

public class ContactRepository {

    public LiveData<List<Contact>> contactList;

    private ContactDao contactDao;

    public ContactRepository(Application application) {

        ContactDatabase database = ContactDatabase.getDatabase(application.getApplicationContext());

        contactDao = database.getContactDao();

        contactList = contactDao.getAllContacts();
    }

    public LiveData<List<Contact>> getContactList(){
        return contactList;
    }

    public void deleteAllContact(){
        ContactDatabase.databaseExecutorWriter.execute(new Runnable() {
            @Override
            public void run() {
                contactDao.deleteAllContact();
            }
        });
    }

    public void insert(Contact contact){
        ContactDatabase.databaseExecutorWriter.execute(new Runnable() {
            @Override
            public void run() {
                contactDao.insert(contact);
            }
        });
    }

    public LiveData<Contact> get(int id){
        return contactDao.get(id);
    }

    public void update(Contact contact){
        ContactDatabase.databaseExecutorWriter.execute(new Runnable() {
            @Override
            public void run() {
                contactDao.update(contact);
            }
        });
    }

    public void delete(Contact contact){
        ContactDatabase.databaseExecutorWriter.execute(new Runnable() {
            @Override
            public void run() {
                contactDao.delete(contact);
            }
        });
    }


}
