package com.example.myapplicationubintu.util;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.example.myapplicationubintu.data.ContactDao;
import com.example.myapplicationubintu.model.Contact;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {Contact.class},version = 1,exportSchema = false)
public abstract class ContactDatabase extends RoomDatabase {

    public abstract ContactDao getContactDao();

    private static volatile ContactDatabase INSTANCE;

    private static final int NUMBER_OF_THREADS = 4;

    public static ExecutorService databaseExecutorWriter =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static ContactDatabase getDatabase(final Context context){
        if(INSTANCE == null){
            synchronized (ContactDatabase.class){
                if(INSTANCE == null){
                    INSTANCE = Room.databaseBuilder(context,ContactDatabase.class,"Contact_Database")
                            .addCallback(sRoomDataBase)
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    private static final RoomDatabase.Callback sRoomDataBase = new RoomDatabase.Callback(){
        @Override
        public void onCreate(@NonNull SupportSQLiteDatabase db) {
            super.onCreate(db);
            ContactDao dao;
             dao= INSTANCE.getContactDao();

             databaseExecutorWriter.execute(new Runnable() {
                 @Override
                 public void run() {
                     dao.deleteAllContact();

                     dao.insert(new Contact("HARI","Android developer","8838387219"));
                     dao.insert(new Contact("Sudershan","Software developer","123-456"));
                 }
             });
        }
    };
}

